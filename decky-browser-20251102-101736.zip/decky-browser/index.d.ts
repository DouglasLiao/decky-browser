import "./styles.css";
declare const _default: (serverAPI: import("decky-frontend-lib").ServerAPI) => import("decky-frontend-lib").Plugin;
export default _default;
