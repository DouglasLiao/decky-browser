import { VFC } from "react";
interface BrowserContainerModalProps {
    serverAPI: any;
}
declare const BrowserContainerModal: VFC<BrowserContainerModalProps>;
export default BrowserContainerModal;
