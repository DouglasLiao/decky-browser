var DeckyBrowser = (function (React, deckyFrontendLib) {
  'use strict';

  function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

  var React__default = /*#__PURE__*/_interopDefaultLegacy(React);

  var jsxRuntime = {exports: {}};

  var reactJsxRuntime_production_min = {};

  /** @license React v16.14.0
   * react-jsx-runtime.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  var f=React__default["default"],g=60103;reactJsxRuntime_production_min.Fragment=60107;if("function"===typeof Symbol&&Symbol.for){var h=Symbol.for;g=h("react.element");reactJsxRuntime_production_min.Fragment=h("react.fragment");}var m=f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,n=Object.prototype.hasOwnProperty,p={key:!0,ref:!0,__self:!0,__source:!0};
  function q(c,a,k){var b,d={},e=null,l=null;void 0!==k&&(e=""+k);void 0!==a.key&&(e=""+a.key);void 0!==a.ref&&(l=a.ref);for(b in a)n.call(a,b)&&!p.hasOwnProperty(b)&&(d[b]=a[b]);if(c&&c.defaultProps)for(b in a=c.defaultProps,a)void 0===d[b]&&(d[b]=a[b]);return {$$typeof:g,type:c,key:e,ref:l,props:d,_owner:m.current}}reactJsxRuntime_production_min.jsx=q;reactJsxRuntime_production_min.jsxs=q;

  {
    jsxRuntime.exports = reactJsxRuntime_production_min;
  }

  var DefaultContext = {
    color: undefined,
    size: undefined,
    className: undefined,
    style: undefined,
    attr: undefined
  };
  var IconContext = React__default["default"].createContext && React__default["default"].createContext(DefaultContext);

  var __assign = window && window.__assign || function () {
    __assign = Object.assign || function (t) {
      for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
      return t;
    };
    return __assign.apply(this, arguments);
  };
  var __rest = window && window.__rest || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
      if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
  };
  function Tree2Element(tree) {
    return tree && tree.map(function (node, i) {
      return React__default["default"].createElement(node.tag, __assign({
        key: i
      }, node.attr), Tree2Element(node.child));
    });
  }
  function GenIcon(data) {
    // eslint-disable-next-line react/display-name
    return function (props) {
      return React__default["default"].createElement(IconBase, __assign({
        attr: __assign({}, data.attr)
      }, props), Tree2Element(data.child));
    };
  }
  function IconBase(props) {
    var elem = function (conf) {
      var attr = props.attr,
        size = props.size,
        title = props.title,
        svgProps = __rest(props, ["attr", "size", "title"]);
      var computedSize = size || conf.size || "1em";
      var className;
      if (conf.className) className = conf.className;
      if (props.className) className = (className ? className + " " : "") + props.className;
      return React__default["default"].createElement("svg", __assign({
        stroke: "currentColor",
        fill: "currentColor",
        strokeWidth: "0"
      }, conf.attr, attr, svgProps, {
        className: className,
        style: __assign(__assign({
          color: props.color || conf.color
        }, conf.style), props.style),
        height: computedSize,
        width: computedSize,
        xmlns: "http://www.w3.org/2000/svg"
      }), title && React__default["default"].createElement("title", null, title), props.children);
    };
    return IconContext !== undefined ? React__default["default"].createElement(IconContext.Consumer, null, function (conf) {
      return elem(conf);
    }) : elem(DefaultContext);
  }

  // THIS FILE IS AUTO GENERATED
  function FaGlobe (props) {
    return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 496 512"},"child":[{"tag":"path","attr":{"d":"M336.5 160C322 70.7 287.8 8 248 8s-74 62.7-88.5 152h177zM152 256c0 22.2 1.2 43.5 3.3 64h185.3c2.1-20.5 3.3-41.8 3.3-64s-1.2-43.5-3.3-64H155.3c-2.1 20.5-3.3 41.8-3.3 64zm324.7-96c-28.6-67.9-86.5-120.4-158-141.6 24.4 33.8 41.2 84.7 50 141.6h108zM177.2 18.4C105.8 39.6 47.8 92.1 19.3 160h108c8.7-56.9 25.5-107.8 49.9-141.6zM487.4 192H372.7c2.1 21 3.3 42.5 3.3 64s-1.2 43-3.3 64h114.6c5.5-20.5 8.6-41.8 8.6-64s-3.1-43.5-8.5-64zM120 256c0-21.5 1.2-43 3.3-64H8.6C3.2 212.5 0 233.8 0 256s3.2 43.5 8.6 64h114.6c-2-21-3.2-42.5-3.2-64zm39.5 96c14.5 89.3 48.7 152 88.5 152s74-62.7 88.5-152h-177zm159.3 141.6c71.4-21.2 129.4-73.7 158-141.6h-108c-8.8 56.9-25.6 107.8-50 141.6zM19.3 352c28.6 67.9 86.5 120.4 158 141.6-24.4-33.8-41.2-84.7-50-141.6h-108z"}}]})(props);
  }

  const BrowserModal = ({ serverAPI }) => {
      const [url, setUrl] = React.useState("https://www.google.com");
      const [currentUrl, setCurrentUrl] = React.useState("https://www.google.com");
      const [isLoading, setIsLoading] = React.useState(false);
      const handleNavigate = () => {
          if (url.trim()) {
              // Adiciona https:// se não tiver protocolo
              const formattedUrl = url.includes("://") ? url : `https://${url}`;
              setCurrentUrl(formattedUrl);
              setIsLoading(true);
          }
      };
      const handleKeyPress = (e) => {
          if (e.key === "Enter") {
              handleNavigate();
          }
      };
      const handleGoHome = () => {
          setUrl("https://www.google.com");
          setCurrentUrl("https://www.google.com");
          setIsLoading(true);
      };
      const handleGoBack = () => {
          const webview = document.getElementById("browser-webview");
          if (webview && webview.canGoBack) {
              webview.goBack();
          }
      };
      const handleGoForward = () => {
          const webview = document.getElementById("browser-webview");
          if (webview && webview.canGoForward) {
              webview.goForward();
          }
      };
      const handleRefresh = () => {
          const webview = document.getElementById("browser-webview");
          if (webview) {
              webview.reload();
              setIsLoading(true);
          }
      };
      const handleWebViewLoad = () => {
          setIsLoading(false);
          const webview = document.getElementById("browser-webview");
          if (webview && webview.src) {
              setUrl(webview.src);
          }
      };
      React.useEffect(() => {
          const webview = document.getElementById("browser-webview");
          if (webview) {
              webview.addEventListener("dom-ready", handleWebViewLoad);
              webview.addEventListener("did-finish-load", handleWebViewLoad);
              return () => {
                  webview.removeEventListener("dom-ready", handleWebViewLoad);
                  webview.removeEventListener("did-finish-load", handleWebViewLoad);
              };
          }
      }, []);
      return (jsxRuntime.exports.jsx(deckyFrontendLib.ConfirmModal, { strTitle: "Simple Browser", strOKButtonText: "Close", onOK: () => window.history.back(), onCancel: () => window.history.back(), bDestructiveWarning: false, children: jsxRuntime.exports.jsxs(deckyFrontendLib.DialogBody, { children: [jsxRuntime.exports.jsxs(deckyFrontendLib.DialogControlsSection, { children: [jsxRuntime.exports.jsxs("div", { style: {
                                  display: "flex",
                                  gap: "8px",
                                  marginBottom: "10px"
                              }, children: [jsxRuntime.exports.jsx("button", { onClick: handleGoBack, disabled: isLoading, title: "Back", style: {
                                          minWidth: "40px",
                                          padding: "8px",
                                          background: "#3d4450",
                                          border: "1px solid #5c6b7a",
                                          borderRadius: "4px",
                                          color: "white",
                                          cursor: "pointer"
                                      }, children: "\u2190" }), jsxRuntime.exports.jsx("button", { onClick: handleGoForward, disabled: isLoading, title: "Forward", style: {
                                          minWidth: "40px",
                                          padding: "8px",
                                          background: "#3d4450",
                                          border: "1px solid #5c6b7a",
                                          borderRadius: "4px",
                                          color: "white",
                                          cursor: "pointer"
                                      }, children: "\u2192" }), jsxRuntime.exports.jsx("button", { onClick: handleRefresh, disabled: isLoading, title: "Refresh", style: {
                                          minWidth: "40px",
                                          padding: "8px",
                                          background: "#3d4450",
                                          border: "1px solid #5c6b7a",
                                          borderRadius: "4px",
                                          color: "white",
                                          cursor: "pointer"
                                      }, children: "\u21BB" }), jsxRuntime.exports.jsx("button", { onClick: handleGoHome, disabled: isLoading, title: "Home", style: {
                                          minWidth: "40px",
                                          padding: "8px",
                                          background: "#3d4450",
                                          border: "1px solid #5c6b7a",
                                          borderRadius: "4px",
                                          color: "white",
                                          cursor: "pointer"
                                      }, children: "\uD83C\uDFE0" })] }), jsxRuntime.exports.jsxs("div", { style: {
                                  display: "flex",
                                  gap: "8px",
                                  marginBottom: "10px"
                              }, children: [jsxRuntime.exports.jsx("input", { value: url, onChange: (e) => setUrl(e.target.value), onKeyPress: handleKeyPress, placeholder: "Enter URL or search term...", style: {
                                          flex: "1",
                                          padding: "8px",
                                          background: "#0e141b",
                                          border: "1px solid #3d4450",
                                          borderRadius: "4px",
                                          color: "white",
                                          fontSize: "14px"
                                      } }), jsxRuntime.exports.jsx("button", { onClick: handleNavigate, disabled: isLoading, style: {
                                          padding: "8px 16px",
                                          background: "#0077be",
                                          border: "1px solid #005a8b",
                                          borderRadius: "4px",
                                          color: "white",
                                          cursor: "pointer"
                                      }, children: "Go" })] }), isLoading && (jsxRuntime.exports.jsx("div", { style: {
                                  textAlign: "center",
                                  margin: "10px 0",
                                  color: "#dcdedf",
                                  fontSize: "14px"
                              }, children: "Loading..." }))] }), jsxRuntime.exports.jsx("div", { style: {
                          width: "100%",
                          height: "500px",
                          border: "1px solid #3d4450",
                          borderRadius: "4px",
                          overflow: "hidden",
                          backgroundColor: "#0e141b"
                      }, children: jsxRuntime.exports.jsx("webview", { id: "browser-webview", src: currentUrl, allowpopups: true, useragent: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36", style: {
                              width: "100%",
                              height: "100%",
                              display: "block",
                              border: "none"
                          } }) })] }) }));
  };

  const BrowserContainerModal = ({ serverAPI }) => {
      const [url, setUrl] = React.useState("https://www.google.com");
      const [isLoading, setIsLoading] = React.useState(true);
      const [containerStatus, setContainerStatus] = React.useState("checking");
      const [browserUrl, setBrowserUrl] = React.useState("");
      React.useEffect(() => {
          checkContainerStatus();
      }, []);
      const checkContainerStatus = async () => {
          try {
              setContainerStatus("checking");
              // Verificar se o container está rodando
              const status = await serverAPI.callPluginMethod("check_browser_container", {});
              if (status.success && status.result.running) {
                  setContainerStatus("running");
                  setBrowserUrl(status.result.url);
                  setIsLoading(false);
              }
              else {
                  setContainerStatus("starting");
                  await startBrowserContainer();
              }
          }
          catch (error) {
              console.error("Erro ao verificar container:", error);
              setContainerStatus("error");
              setIsLoading(false);
          }
      };
      const startBrowserContainer = async () => {
          try {
              setContainerStatus("starting");
              const result = await serverAPI.callPluginMethod("start_browser_container", {});
              if (result.success) {
                  setContainerStatus("running");
                  setBrowserUrl(result.result.url);
                  setIsLoading(false);
              }
              else {
                  setContainerStatus("error");
                  setIsLoading(false);
              }
          }
          catch (error) {
              console.error("Erro ao iniciar container:", error);
              setContainerStatus("error");
              setIsLoading(false);
          }
      };
      const navigateTo = async (newUrl) => {
          try {
              setIsLoading(true);
              const formattedUrl = newUrl.includes("://") ? newUrl : `https://${newUrl}`;
              await serverAPI.callPluginMethod("navigate_browser", { url: formattedUrl });
              setUrl(formattedUrl);
              setIsLoading(false);
          }
          catch (error) {
              console.error("Erro ao navegar:", error);
              setIsLoading(false);
          }
      };
      const handleNavigate = () => {
          if (url.trim()) {
              navigateTo(url);
          }
      };
      const handleKeyPress = (e) => {
          if (e.key === "Enter") {
              handleNavigate();
          }
      };
      const handleGoHome = () => {
          navigateTo("https://www.google.com");
      };
      const restartContainer = async () => {
          try {
              setContainerStatus("restarting");
              setIsLoading(true);
              await serverAPI.callPluginMethod("restart_browser_container", {});
              // Aguardar um pouco e verificar status novamente
              setTimeout(() => {
                  checkContainerStatus();
              }, 3000);
          }
          catch (error) {
              console.error("Erro ao reiniciar container:", error);
              setContainerStatus("error");
              setIsLoading(false);
          }
      };
      const getStatusMessage = () => {
          switch (containerStatus) {
              case "checking":
                  return "Verificando container...";
              case "starting":
                  return "Iniciando browser isolado...";
              case "restarting":
                  return "Reiniciando container...";
              case "running":
                  return "Browser rodando em container isolado";
              case "error":
                  return "Erro no container do browser";
              default:
                  return "Status desconhecido";
          }
      };
      const getStatusColor = () => {
          switch (containerStatus) {
              case "running":
                  return "#4ade80";
              case "error":
                  return "#ef4444";
              default:
                  return "#f59e0b";
          }
      };
      return (jsxRuntime.exports.jsx(deckyFrontendLib.ConfirmModal, { strTitle: "Browser Isolado (Docker)", strOKButtonText: "Fechar", onOK: () => window.history.back(), onCancel: () => window.history.back(), bDestructiveWarning: false, children: jsxRuntime.exports.jsxs(deckyFrontendLib.DialogBody, { children: [jsxRuntime.exports.jsx(deckyFrontendLib.DialogControlsSection, { children: jsxRuntime.exports.jsxs("div", { style: {
                              padding: "10px",
                              borderRadius: "4px",
                              backgroundColor: "#1a1a1a",
                              marginBottom: "10px",
                              textAlign: "center"
                          }, children: [jsxRuntime.exports.jsx("div", { style: {
                                      color: getStatusColor(),
                                      fontWeight: "bold",
                                      marginBottom: "5px"
                                  }, children: getStatusMessage() }), browserUrl && (jsxRuntime.exports.jsxs("div", { style: { fontSize: "12px", color: "#aaa" }, children: ["Container: ", browserUrl] }))] }) }), containerStatus === "running" && (jsxRuntime.exports.jsxs(deckyFrontendLib.DialogControlsSection, { children: [jsxRuntime.exports.jsxs("div", { style: {
                                  display: "flex",
                                  gap: "8px",
                                  marginBottom: "10px"
                              }, children: [jsxRuntime.exports.jsx("button", { onClick: () => navigateTo("javascript:history.back()"), disabled: isLoading, title: "Voltar", style: {
                                          minWidth: "40px",
                                          padding: "8px",
                                          background: "#3d4450",
                                          border: "1px solid #5c6b7a",
                                          borderRadius: "4px",
                                          color: "white",
                                          cursor: "pointer"
                                      }, children: "\u2190" }), jsxRuntime.exports.jsx("button", { onClick: () => navigateTo("javascript:history.forward()"), disabled: isLoading, title: "Avan\u00E7ar", style: {
                                          minWidth: "40px",
                                          padding: "8px",
                                          background: "#3d4450",
                                          border: "1px solid #5c6b7a",
                                          borderRadius: "4px",
                                          color: "white",
                                          cursor: "pointer"
                                      }, children: "\u2192" }), jsxRuntime.exports.jsx("button", { onClick: () => navigateTo("javascript:location.reload()"), disabled: isLoading, title: "Refresh", style: {
                                          minWidth: "40px",
                                          padding: "8px",
                                          background: "#3d4450",
                                          border: "1px solid #5c6b7a",
                                          borderRadius: "4px",
                                          color: "white",
                                          cursor: "pointer"
                                      }, children: "\u21BB" }), jsxRuntime.exports.jsx("button", { onClick: handleGoHome, disabled: isLoading, title: "Home", style: {
                                          minWidth: "40px",
                                          padding: "8px",
                                          background: "#3d4450",
                                          border: "1px solid #5c6b7a",
                                          borderRadius: "4px",
                                          color: "white",
                                          cursor: "pointer"
                                      }, children: "\uD83C\uDFE0" }), jsxRuntime.exports.jsx("button", { onClick: restartContainer, disabled: isLoading, title: "Reiniciar Container", style: {
                                          minWidth: "40px",
                                          padding: "8px",
                                          background: "#3d4450",
                                          border: "1px solid #5c6b7a",
                                          borderRadius: "4px",
                                          color: "white",
                                          cursor: "pointer"
                                      }, children: "\uD83D\uDD04" })] }), jsxRuntime.exports.jsxs("div", { style: {
                                  display: "flex",
                                  gap: "8px",
                                  marginBottom: "10px"
                              }, children: [jsxRuntime.exports.jsx("input", { value: url, onChange: (e) => setUrl(e.target.value), onKeyPress: handleKeyPress, placeholder: "Digite URL ou termo de busca...", disabled: isLoading, style: {
                                          flex: "1",
                                          padding: "8px",
                                          background: "#0e141b",
                                          border: "1px solid #3d4450",
                                          borderRadius: "4px",
                                          color: "white",
                                          fontSize: "14px"
                                      } }), jsxRuntime.exports.jsx("button", { onClick: handleNavigate, disabled: isLoading, style: {
                                          padding: "8px 16px",
                                          background: "#0077be",
                                          border: "1px solid #005a8b",
                                          borderRadius: "4px",
                                          color: "white",
                                          cursor: "pointer"
                                      }, children: "Ir" })] }), isLoading && (jsxRuntime.exports.jsx("div", { style: {
                                  textAlign: "center",
                                  margin: "10px 0",
                                  color: "#dcdedf",
                                  fontSize: "14px"
                              }, children: "Navegando..." }))] })), containerStatus === "running" && browserUrl ? (jsxRuntime.exports.jsx("div", { style: {
                          width: "100%",
                          height: "500px",
                          border: "1px solid #3d4450",
                          borderRadius: "4px",
                          overflow: "hidden",
                          backgroundColor: "#0e141b"
                      }, children: jsxRuntime.exports.jsx("iframe", { src: browserUrl, title: "Browser Isolado", frameBorder: "0", allowFullScreen: true, style: {
                              width: "100%",
                              height: "100%",
                              display: "block",
                              border: "none"
                          } }) })) : containerStatus === "error" ? (jsxRuntime.exports.jsxs("div", { style: {
                          textAlign: "center",
                          padding: "40px",
                          color: "#ef4444"
                      }, children: [jsxRuntime.exports.jsx("div", { style: { fontSize: "48px", marginBottom: "20px" }, children: "\u26A0\uFE0F" }), jsxRuntime.exports.jsx("div", { style: { fontSize: "18px", marginBottom: "10px" }, children: "Erro no Container do Browser" }), jsxRuntime.exports.jsx("div", { style: { fontSize: "14px", marginBottom: "20px", color: "#aaa" }, children: "O container Docker n\u00E3o p\u00F4de ser iniciado" }), jsxRuntime.exports.jsx("button", { onClick: checkContainerStatus, style: {
                                  padding: "8px 16px",
                                  background: "#0077be",
                                  border: "1px solid #005a8b",
                                  borderRadius: "4px",
                                  color: "white",
                                  cursor: "pointer"
                              }, children: "Tentar Novamente" })] })) : (jsxRuntime.exports.jsxs("div", { style: {
                          textAlign: "center",
                          padding: "40px",
                          color: "#f59e0b"
                      }, children: [jsxRuntime.exports.jsx("div", { style: { fontSize: "48px", marginBottom: "20px" }, children: "\uD83D\uDC33" }), jsxRuntime.exports.jsx("div", { style: { fontSize: "18px", marginBottom: "10px" }, children: "Preparando Browser Isolado" }), jsxRuntime.exports.jsx("div", { style: { fontSize: "14px", color: "#aaa" }, children: getStatusMessage() })] }))] }) }));
  };

  const Content = ({ serverAPI }) => {
      const openBrowser = () => {
          deckyFrontendLib.showModal(jsxRuntime.exports.jsx(deckyFrontendLib.ModalRoot, { children: jsxRuntime.exports.jsx(BrowserModal, { serverAPI: serverAPI }) }));
      };
      const openContainerBrowser = () => {
          deckyFrontendLib.showModal(jsxRuntime.exports.jsx(deckyFrontendLib.ModalRoot, { children: jsxRuntime.exports.jsx(BrowserContainerModal, { serverAPI: serverAPI }) }));
      };
      return (jsxRuntime.exports.jsxs("div", { style: {
              marginTop: "50px",
              color: "white"
          }, children: [jsxRuntime.exports.jsx("div", { style: {
                      fontSize: "20px",
                      textAlign: "center",
                      marginBottom: "20px"
                  }, children: "Simple Browser" }), jsxRuntime.exports.jsxs("div", { style: {
                      textAlign: "center",
                      marginTop: "20px",
                      display: "flex",
                      flexDirection: "column",
                      gap: "10px",
                      alignItems: "center"
                  }, children: [jsxRuntime.exports.jsxs("button", { onClick: openBrowser, style: {
                              minHeight: "40px",
                              minWidth: "200px",
                              background: "linear-gradient(135deg, #0077be, #005a8b)",
                              border: "none",
                              borderRadius: "8px",
                              color: "white",
                              fontSize: "16px",
                              fontWeight: "bold",
                              cursor: "pointer",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              gap: "10px",
                              transition: "all 0.3s ease"
                          }, children: [jsxRuntime.exports.jsx(FaGlobe, {}), "Browser WebView"] }), jsxRuntime.exports.jsx("button", { onClick: openContainerBrowser, style: {
                              minHeight: "40px",
                              minWidth: "200px",
                              background: "linear-gradient(135deg, #1e40af, #1e3a8a)",
                              border: "none",
                              borderRadius: "8px",
                              color: "white",
                              fontSize: "16px",
                              fontWeight: "bold",
                              cursor: "pointer",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              gap: "10px",
                              transition: "all 0.3s ease"
                          }, children: "\uD83D\uDC33 Browser Isolado (Docker)" }), jsxRuntime.exports.jsxs("div", { style: {
                              fontSize: "12px",
                              color: "#888",
                              textAlign: "center",
                              marginTop: "10px",
                              maxWidth: "250px"
                          }, children: ["Browser isolado roda em container Docker", jsxRuntime.exports.jsx("br", {}), "independente das atualiza\u00E7\u00F5es do Steam Deck"] })] })] }));
  };
  var index = deckyFrontendLib.definePlugin((serverApi) => {
      return {
          title: jsxRuntime.exports.jsx("div", { className: deckyFrontendLib.staticClasses.Title, children: "Simple Browser" }),
          content: jsxRuntime.exports.jsx(Content, { serverAPI: serverApi }),
          icon: jsxRuntime.exports.jsx(FaGlobe, {}),
          onDismount() {
              // Cleanup if needed
          },
      };
  });

  return index;

})(SP_REACT, DFL);
