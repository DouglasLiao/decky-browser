#!/bin/bash

# Script de instalação do Decky Browser Plugin para Steam Deck
# Execute este script no modo desktop do Steam Deck

set -e

# Cores
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}=== Instalando Decky Browser Plugin ===${NC}"

# Verificar se está no Steam Deck
if [ ! -f "/etc/os-release" ] || ! grep -q "steamdeck" /etc/os-release 2>/dev/null; then
    echo -e "${YELLOW}Aviso: Este script foi feito para Steam Deck, mas pode funcionar em outros sistemas Linux.${NC}"
fi

# Determinar o diretório do Decky Loader
DECKY_HOME="${DECKY_HOME:-$HOME/homebrew}"

if [ ! -d "$DECKY_HOME" ]; then
    echo -e "${RED}✗ Decky Loader não encontrado em: $DECKY_HOME${NC}"
    echo -e "${YELLOW}Certifique-se de que o Decky Loader está instalado.${NC}"
    echo -e "${BLUE}Para instalar o Decky Loader, visite: https://deckbrew.xyz${NC}"
    exit 1
fi

# Diretório do plugin
PLUGIN_DIR="$DECKY_HOME/plugins/decky-browser"

echo -e "${BLUE}Instalando em: $PLUGIN_DIR${NC}"

# Criar diretório do plugin se não existir
mkdir -p "$PLUGIN_DIR"

# Copiar arquivos
echo -e "${YELLOW}Copiando arquivos do plugin...${NC}"
cp -r ./* "$PLUGIN_DIR/" 2>/dev/null || true

# Remover o próprio script de instalação do diretório do plugin
rm -f "$PLUGIN_DIR/install.sh" 2>/dev/null || true
rm -f "$PLUGIN_DIR/README-INSTALL.txt" 2>/dev/null || true

# Verificar se os arquivos essenciais estão presentes
if [ ! -f "$PLUGIN_DIR/index.js" ]; then
    echo -e "${RED}✗ Erro: index.js não encontrado!${NC}"
    exit 1
fi

if [ ! -f "$PLUGIN_DIR/main.py" ]; then
    echo -e "${RED}✗ Erro: main.py não encontrado!${NC}"
    exit 1
fi

if [ ! -f "$PLUGIN_DIR/plugin.json" ]; then
    echo -e "${RED}✗ Erro: plugin.json não encontrado!${NC}"
    exit 1
fi

# Definir permissões
chmod 644 "$PLUGIN_DIR"/*.json 2>/dev/null || true
chmod 644 "$PLUGIN_DIR"/*.js 2>/dev/null || true
chmod 644 "$PLUGIN_DIR"/*.py 2>/dev/null || true

echo -e "${GREEN}✓ Plugin instalado com sucesso!${NC}"
echo -e "${YELLOW}Próximos passos:${NC}"
echo -e "${BLUE}1. Reinicie o Decky Loader ou reinicie o Steam Deck${NC}"
echo -e "${BLUE}2. Abra o menu rápido (botão ... do Steam Deck)${NC}"
echo -e "${BLUE}3. Procure por 'Simple Browser' na lista de plugins${NC}"
echo -e "${BLUE}4. Clique no ícone de globo para abrir o browser${NC}"
echo ""
echo -e "${GREEN}Instalação concluída!${NC}"
