import { VFC } from "react";
interface BrowserModalProps {
    serverAPI: any;
}
declare const BrowserModal: VFC<BrowserModalProps>;
export default BrowserModal;
