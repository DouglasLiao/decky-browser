=== INSTRUÇÕES DE INSTALAÇÃO - DECKY BROWSER PLUGIN ===

PASSO 1: PREPARAÇÃO
- Certifique-se de que o Decky Loader está instalado no seu Steam Deck
- Se não estiver instalado, visite: https://deckbrew.xyz
- Baixe e extraia este arquivo ZIP

PASSO 2: INSTALAÇÃO AUTOMÁTICA (RECOMENDADO)
1. Abra o modo desktop no Steam Deck
2. Abra o gerenciador de arquivos (Dolphin)
3. Navegue até a pasta onde extraiu este ZIP
4. Clique duas vezes no arquivo "install.sh"
5. Ou abra um terminal e execute: bash install.sh

PASSO 3: INSTALAÇÃO MANUAL (SE AUTOMÁTICA FALHAR)
1. Abra o gerenciador de arquivos
2. Navegue até: /home/deck/homebrew/plugins/
3. Crie uma pasta chamada: decky-browser
4. Copie todos os arquivos desta pasta (exceto install.sh e este README) para:
   /home/deck/homebrew/plugins/decky-browser/

PASSO 4: ATIVAR O PLUGIN
1. Reinicie o Steam Deck OU
2. Vá em Configurações > Plugins > Reload no Decky Loader
3. Abra o menu rápido (botão ...)
4. Procure por "Simple Browser" na lista de plugins
5. Clique no ícone de globo para abrir

ARQUIVOS INCLUSOS:
- index.js      -> Frontend do plugin (obrigatório)
- main.py       -> Backend do plugin (obrigatório)  
- plugin.json   -> Configuração do plugin (obrigatório)
- package.json  -> Metadados do plugin
- install.sh    -> Script de instalação automática

TROUBLESHOOTING:
- Se o plugin não aparecer, verifique se todos os arquivos estão em:
  /home/deck/homebrew/plugins/decky-browser/
- Certifique-se de que o Decky Loader está funcionando
- Reinicie o Steam Deck se necessário
- Verifique os logs em: Configurações > Plugins > View Logs

FUNCIONALIDADES:
- Browser leve baseado em WebView
- Navegação com botões voltar/avançar/refresh/home
- Barra de endereços com auto-detecção de protocolo
- Interface otimizada para Steam Deck
- Homepage configurada para Google

Para mais informações, visite o repositório do projeto.
